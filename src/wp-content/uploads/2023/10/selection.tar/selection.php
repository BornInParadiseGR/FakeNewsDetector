<?php
/*
Plugin Name: URL and Text Selector
Description: Add URL and text input fields to your posts or pages.
Version: 1.0
Author: Your Name
*/

// Create the URL and Text input shortcode
function url_text_selector_shortcode($atts) {
    $output = '<div class="url-text-selector">';
    $output .= '<label for="url-input">Enter a URL:</label>';
    $output .= '<input type="url" id="url-input" name="url-input" required>';
    $output .= '<br>';
    $output .= '<label for="text-input">Enter some text:</label>';
    $output .= '<input type="text" id="text-input" name="text-input" required>';
    $output .= '</div>';

    return $output;
}

add_shortcode('url-text-selector', 'url_text_selector_shortcode');
